<?php
return [
    'adminEmail' => 'admin@infoedgenetwork.com',
    'supportEmail' => 'support@infoedgenetwork.com',
    'senderEmail' => 'noreply@infoedgenetwork.com',
    'senderName' => 'infoedgenetwork.com mailer',
    'user.passwordResetTokenExpire' => 3600,
    'user.passwordMinLength' => 8,
    'copyright' => 'Copyright @ 2020 Optimum Performance Solutions Ltd. - All rights reserved.',
];
